package com.aibers.dashboard;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/requests")
public class MakerCheckerController {
    private List<Request> requests = new ArrayList<>();
    private Long nextId = 1L;

    @GetMapping
    public List<Request> getAllRequests() {
        return requests;
    }

    @PostMapping
    public Request createRequest(@RequestBody Map<String, String> body) {
        Request req = new Request(nextId++, body.get("maker"), body.get("description"), "Pending");
        requests.add(req);
        return req;
    }

    @PutMapping("/{id}")
    public Request updateStatus(@PathVariable Long id, @RequestBody Map<String, String> body) {
        for (Request req : requests) {
            if (req.getId().equals(id)) {
                req.setStatus(body.get("status"));
                return req;
            }
        }
        throw new NoSuchElementException("Request not found");
    }
}