package com.aibers.dashboard;

public class Request {
    private Long id;
    private String maker;
    private String description;
    private String status;

    // Constructors, getters, setters
    public Request() {}
    public Request(Long id, String maker, String description, String status) {
        this.id = id;
        this.maker = maker;
        this.description = description;
        this.status = status;
    }

    public Long getId() { return id; }
    public String getMaker() { return maker; }
    public String getDescription() { return description; }
    public String getStatus() { return status; }

    public void setId(Long id) { this.id = id; }
    public void setMaker(String maker) { this.maker = maker; }
    public void setDescription(String description) { this.description = description; }
    public void setStatus(String status) { this.status = status; }
}