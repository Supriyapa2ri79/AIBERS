package com.aibers.dashboard.controller;

import com.aibers.dashboard.model.User;
import com.aibers.dashboard.repository.UserRepository;
import com.aibers.dashboard.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    @Autowired private UserRepository userRepo;
    @Autowired private JwtUtil jwtUtil;

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody Map<String, String> body) {
        User user = userRepo.findByUsername(body.get("username"));
        if (user != null && user.getPassword().equals(body.get("password"))) { // hash in production!
            String token = jwtUtil.generateToken(user.getUsername(), user.getRole());
            return Map.of("token", token, "user", user);
        }
        throw new RuntimeException("Invalid credentials");
    }
}