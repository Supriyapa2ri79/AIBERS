package com.aibers.dashboard.model;

import jakarta.persistence.*;

@Entity
public class Request {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String maker;
    private String description;
    private String status; // Pending, Approved, Rejected
    // getters/setters
}