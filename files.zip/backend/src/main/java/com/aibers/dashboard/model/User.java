package com.aibers.dashboard.model;

import jakarta.persistence.*;

@Entity
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    private String password; // hashed
    private String role; // "Maker" or "Checker"
    // getters/setters
}