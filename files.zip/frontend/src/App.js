import React from "react";
import MakerCheckerDashboard from "./components/MakerCheckerDashboard/MakerCheckerDashboard";
import "./App.css";

function App() {
  return (
    <div className="App">
      <MakerCheckerDashboard />
    </div>
  );
}

export default App;